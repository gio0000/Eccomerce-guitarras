from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# Configuração do banco de dados
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="eccomerce_db"
)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/criarconta')
def criarconta():
    return render_template('criarconta.html')
@app.route('/cadastrar', methods=['POST'])
def cadastrar():
    usuario = request.form['usuario']
    email = request.form['email']
    data_nascimento = request.form['data_nascimento']
    senha = request.form['senha']
    
    cursor = db.cursor()
    sql = "INSERT INTO usuarios (usuario, email, data_nascimento, senha) VALUES (%s, %s, %s, %s)"
    val = (usuario, email, data_nascimento, senha)
    cursor.execute(sql, val)
    db.commit()
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
