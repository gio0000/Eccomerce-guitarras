from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# Configurações do banco de dados
db_config = {
    'host': 'localhost',  # ex: 'localhost'
    'user': 'root',
    'password': '',
    'database': 'eccomerce_db'
}

@app.route('/')
def index():
    return render_template('criarconta.html')

@app.route('/criarconta', methods=['POST'])
def criar_conta():
    nome = request.form['nome']
    email = request.form['email']
    data_nascimento = request.form['data_nascimento']
    senha = request.form['senha']

    # Conectar ao banco de dados
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()

    # Inserir os dados na tabela
    cursor.execute("""
        INSERT INTO cadastros (nome, email, data_nascimento, senha) 
        VALUES (%s, %s, %s, %s)
    """, (nome, email, data_nascimento, senha))

    # Salvar mudanças e fechar conexão
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
